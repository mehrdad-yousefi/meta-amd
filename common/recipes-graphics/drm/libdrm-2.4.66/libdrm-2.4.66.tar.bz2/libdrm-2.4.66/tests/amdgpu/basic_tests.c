/*
 * Copyright 2014 Advanced Micro Devices, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE COPYRIGHT HOLDER(S) OR AUTHOR(S) BE LIABLE FOR ANY CLAIM, DAMAGES OR
 * OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 *
*/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>
#ifdef HAVE_ALLOCA_H
# include <alloca.h>
#endif

#include "CUnit/Basic.h"

#include "amdgpu_test.h"
#include "amdgpu_drm.h"

static  amdgpu_device_handle device_handle;
static  uint32_t  major_version;
static  uint32_t  minor_version;

static void amdgpu_query_info_test(void);
static void amdgpu_memory_alloc(void);
static void amdgpu_command_submission_gfx(void);
static void amdgpu_command_submission_compute(void);
static void amdgpu_command_submission_sdma(void);
static void amdgpu_command_submission_multi_fence(void);
static void amdgpu_userptr_test(void);
static void amdgpu_semaphore_test(void);
static void amdgpu_svm_test(void);
static void amdgpu_multi_svm_test(void);
static void amdgpu_va_range_test(void);

CU_TestInfo basic_tests[] = {
	{ "Query Info Test",  amdgpu_query_info_test },
	{ "Memory alloc Test",  amdgpu_memory_alloc },
	{ "Userptr Test",  amdgpu_userptr_test },
	{ "Command submission Test (GFX)",  amdgpu_command_submission_gfx },
	{ "Command submission Test (Compute)", amdgpu_command_submission_compute },
	{ "Command submission Test (SDMA)", amdgpu_command_submission_sdma },
	{ "Command submission Test (Multi-fence)", amdgpu_command_submission_multi_fence },
	{ "SW semaphore Test",  amdgpu_semaphore_test },
	{ "VA range Test", amdgpu_va_range_test},
	{ "SVM Test", amdgpu_svm_test },
	{ "SVM Test (multi-GPUs)", amdgpu_multi_svm_test },
	CU_TEST_INFO_NULL,
};
#define BUFFER_SIZE (8 * 1024)
#define SVM_TEST_COUNT 16
#define SDMA_PKT_HEADER_op_offset 0
#define SDMA_PKT_HEADER_op_mask   0x000000FF
#define SDMA_PKT_HEADER_op_shift  0
#define SDMA_PKT_HEADER_OP(x) (((x) & SDMA_PKT_HEADER_op_mask) << SDMA_PKT_HEADER_op_shift)
#define SDMA_OPCODE_CONSTANT_FILL  11
#       define SDMA_CONSTANT_FILL_EXTRA_SIZE(x)           ((x) << 14)
	/* 0 = byte fill
	 * 2 = DW fill
	 */
#define SDMA_PACKET(op, sub_op, e)	((((e) & 0xFFFF) << 16) |	\
					(((sub_op) & 0xFF) << 8) |	\
					(((op) & 0xFF) << 0))
#define	SDMA_OPCODE_WRITE				  2
#       define SDMA_WRITE_SUB_OPCODE_LINEAR               0
#       define SDMA_WRTIE_SUB_OPCODE_TILED                1

#define	SDMA_OPCODE_COPY				  1
#       define SDMA_COPY_SUB_OPCODE_LINEAR                0

#define GFX_COMPUTE_NOP  0xffff1000
#define SDMA_NOP  0x0

int suite_basic_tests_init(void)
{
	int r;

	r = amdgpu_device_initialize(drm_amdgpu[0], &major_version,
				   &minor_version, &device_handle);

	if (r == 0)
		return CUE_SUCCESS;
	else
		return CUE_SINIT_FAILED;
}

int suite_basic_tests_clean(void)
{
	int r = amdgpu_device_deinitialize(device_handle);

	if (r == 0)
		return CUE_SUCCESS;
	else
		return CUE_SCLEAN_FAILED;
}

static void amdgpu_query_hw_info_test(unsigned type)
{
	int r;
	int i;
	bool first_ring = true;
	struct drm_amdgpu_info_hw_ip ip_info;
	char *name;

	name = amdgpu_hw_ip_type_to_name(type);
	CU_ASSERT_NOT_EQUAL(name, NULL);

	r = amdgpu_query_hw_ip_info(device_handle, type,
				0, &ip_info);

	CU_ASSERT_EQUAL(r, 0);

	amdgpu_vprintf("\n    %s HW IP...\n", name);
	amdgpu_vprintf("    major version:%d\n", ip_info.hw_ip_version_major);
	amdgpu_vprintf("    minor version:%d\n", ip_info.hw_ip_version_minor);
	amdgpu_vprintf("    capabilities_flags:0x%llx\n",
					ip_info.capabilities_flags);
	amdgpu_vprintf("    IB start alignment:%d\n", ip_info.ib_start_alignment);
	amdgpu_vprintf("    IB size alignment:%d\n", ip_info.ib_size_alignment);
	amdgpu_vprintf("    Following rings are supported: ");
	for (i = 0; i < 8; i++)
		if (ip_info.available_rings & 1 << i) {
			if (first_ring)
				first_ring = false;
			else
				amdgpu_vprintf(", ");

			amdgpu_vprintf("%d", i);
		}

	amdgpu_vprintf(".\n");
}

static void amdgpu_query_gpu_info_test()
{
	struct amdgpu_gpu_info gpu_info = {0};
	int r;
	int i, j;

	r = amdgpu_query_gpu_info(device_handle, &gpu_info);
	CU_ASSERT_EQUAL(r, 0);

	amdgpu_vprintf("\n    GPU info...\n");

	amdgpu_vprintf("    Asic id:");
	amdgpu_vprintf("0x%x\n", gpu_info.asic_id);
	amdgpu_vprintf("    Chip revision:");
	amdgpu_vprintf("0x%x\n", gpu_info.chip_rev);
	amdgpu_vprintf("    Chip external revision:");
	amdgpu_vprintf("0x%x\n", gpu_info.chip_external_rev);
	amdgpu_vprintf("    Family ID:");
	amdgpu_vprintf("0x%x\n", gpu_info.family_id);
	amdgpu_vprintf("    Special flags:");
	amdgpu_vprintf("0x%llx\n", gpu_info.ids_flags);
	amdgpu_vprintf("    max engine clock:");
	amdgpu_vprintf("0x%llx\n", gpu_info.max_engine_clk);
	amdgpu_vprintf("    max memory clock:");
	amdgpu_vprintf("0x%llx\n", gpu_info.max_memory_clk);
	amdgpu_vprintf("    number of shader engines:");
	amdgpu_vprintf("0x%x\n", gpu_info.num_shader_engines);
	amdgpu_vprintf("    number of shader arrays per engine:");
	amdgpu_vprintf("0x%x\n", gpu_info.num_shader_arrays_per_engine);
	amdgpu_vprintf("    Number of available good shader pipes:");
	amdgpu_vprintf("0x%x\n", gpu_info.avail_quad_shader_pipes);
	amdgpu_vprintf("    Max. number of shader pipes."
					"(including good and bad pipes :");
	amdgpu_vprintf("0x%x\n", gpu_info.max_quad_shader_pipes);
	amdgpu_vprintf("    Number of parameter cache entries per shader quad "
					"pipe:");
	amdgpu_vprintf("0x%x\n", gpu_info.cache_entries_per_quad_pipe);
	amdgpu_vprintf("    Number of available graphics context:");
	amdgpu_vprintf("0x%x\n", gpu_info.num_hw_gfx_contexts);
	amdgpu_vprintf("    Number of render backend pipes:");
	amdgpu_vprintf("0x%x\n", gpu_info.rb_pipes);
	amdgpu_vprintf("    Enabled render backend pipe mask:");
	amdgpu_vprintf("0x%x\n", gpu_info.enabled_rb_pipes_mask);
	amdgpu_vprintf("    Frequency of GPU Counter:");
	amdgpu_vprintf("0x%x\n", gpu_info.gpu_counter_freq);

	amdgpu_vprintf("    CC_RB_BACKEND_DISABLE.BACKEND_DISABLE per SE:\n");
	for (i = 0; i < 4; i++)
		amdgpu_vprintf("      [%d]=0x%x\n", i, gpu_info.backend_disable[i]);

	amdgpu_vprintf("    Value of MC_ARB_RAMCFG register:");
	amdgpu_vprintf("0x%x\n", gpu_info.mc_arb_ramcfg);
	amdgpu_vprintf("    Value of GB_ADDR_CONFIG:");
	amdgpu_vprintf("0x%x\n", gpu_info.gb_addr_cfg);

	amdgpu_vprintf("    Values of the GB_TILE_MODE0..31 registers:\n");
	for (i = 0; i < 32; i++)
		amdgpu_vprintf("      [%d]=0x%x\n", i, gpu_info.gb_tile_mode[i]);

	amdgpu_vprintf("    Values of GB_MACROTILE_MODE0..15 registers:\n");
	for (i = 0; i < 16; i++)
		amdgpu_vprintf("      [%d]=0x%x\n", i, gpu_info.gb_macro_tile_mode[i]);

	amdgpu_vprintf("    Value of PA_SC_RASTER_CONFIG register per SE:\n");
	for (i = 0; i < 4; i++)
		amdgpu_vprintf("      [%d]=0x%x\n", i, gpu_info.pa_sc_raster_cfg[i]);

	amdgpu_vprintf("    Value of PA_SC_RASTER_CONFIG_1 register per SE:\n");
	for (i = 0; i < 4; i++)
		amdgpu_vprintf("      [%d]=0x%x\n", i, gpu_info.pa_sc_raster_cfg1[i]);

	amdgpu_vprintf("    CU info (active number):");
	amdgpu_vprintf("0x%x\n", gpu_info.cu_active_number);
	amdgpu_vprintf("    CU info (AU mask):");
	amdgpu_vprintf("0x%x\n", gpu_info.cu_ao_mask);

	amdgpu_vprintf("    CU info (AU bit map):");
	for (i = 0; i < 4; i++) {
		amdgpu_vprintf("\n      ");
		for (j = 0; j < 4; j++)
			amdgpu_vprintf(" [%d][%d]=0x%08x", i, j, gpu_info.cu_bitmap[i][j]);
	}
	amdgpu_vprintf("\n");

	amdgpu_vprintf("    video memory type info:");
	amdgpu_vprintf("0x%x\n", gpu_info.vram_type);
	amdgpu_vprintf("    video memory bit width:");
	amdgpu_vprintf("0x%x\n", gpu_info.vram_bit_width);
	amdgpu_vprintf("    constant engine ram size:");
	amdgpu_vprintf("0x%x\n", gpu_info.ce_ram_size);
	amdgpu_vprintf("    vce harvesting instance:");
	amdgpu_vprintf("0x%x\n", gpu_info.vce_harvest_config);
	amdgpu_vprintf("    PCI revision ID:");
	amdgpu_vprintf("0x%x\n", gpu_info.pci_rev_id);
}

static void amdgpu_query_firmware_info_test(void)
{
	uint32_t version, feature;
	int r;

	r = amdgpu_query_firmware_version(device_handle, AMDGPU_INFO_FW_VCE, 0,
					  0, &version, &feature);
	CU_ASSERT_EQUAL(r, 0);
	amdgpu_vprintf("\n    VCE firmware info...\n");
	amdgpu_vprintf("    vce version: 0x%x\n", version);
	amdgpu_vprintf("    vce feature: 0x%x\n", feature);
}

static void amdgpu_query_heap_info_test(void)
{
	struct amdgpu_heap_info info;
	uint64_t total_vram, total_vram_used;

	amdgpu_query_heap_info(device_handle, AMDGPU_GEM_DOMAIN_VRAM,
			       0, &info);
	total_vram = info.heap_size;
	total_vram_used = info.heap_usage;

	amdgpu_query_heap_info(device_handle, AMDGPU_GEM_DOMAIN_VRAM,
			       AMDGPU_GEM_CREATE_CPU_ACCESS_REQUIRED, &info);
	amdgpu_vprintf("\n    Visible VRAM info...\n");
	amdgpu_vprintf("    size: 0x%"PRIx64"\n", info.heap_size);
	amdgpu_vprintf("    usage: 0x%"PRIx64"\n", info.heap_usage);
	amdgpu_vprintf("\n    Invisible VRAM info...\n");
	amdgpu_vprintf("    size: 0x%"PRIx64"\n", total_vram - info.heap_size);
	amdgpu_vprintf("    usage: 0x%"PRIx64"\n", total_vram_used - info.heap_usage);

	amdgpu_query_heap_info(device_handle, AMDGPU_GEM_DOMAIN_GTT,
			       0, &info);
	amdgpu_vprintf("\n    GTT info...\n");
	amdgpu_vprintf("    size: 0x%"PRIx64"\n", info.heap_size);
	amdgpu_vprintf("    usage: 0x%"PRIx64"\n", info.heap_usage);
}

static void amdgpu_query_info_test(void)
{
	amdgpu_query_gpu_info_test();
	amdgpu_query_firmware_info_test();
	amdgpu_query_hw_info_test(AMDGPU_HW_IP_GFX);
	amdgpu_query_hw_info_test(AMDGPU_HW_IP_COMPUTE);
	amdgpu_query_hw_info_test(AMDGPU_HW_IP_DMA);
	amdgpu_query_hw_info_test(AMDGPU_HW_IP_UVD);
	amdgpu_query_hw_info_test(AMDGPU_HW_IP_VCE);
	amdgpu_query_heap_info_test();
}

static void amdgpu_memory_alloc(void)
{
	amdgpu_bo_handle bo;
	amdgpu_va_handle va_handle;
	uint64_t bo_mc;
	int r;

	/* Test visible VRAM */
	bo = gpu_mem_alloc(device_handle,
			4096, 4096,
			AMDGPU_GEM_DOMAIN_VRAM,
			AMDGPU_GEM_CREATE_CPU_ACCESS_REQUIRED,
			&bo_mc, &va_handle);

	r = gpu_mem_free(bo, va_handle, bo_mc, 4096);
	CU_ASSERT_EQUAL(r, 0);

	/* Test invisible VRAM */
	bo = gpu_mem_alloc(device_handle,
			4096, 4096,
			AMDGPU_GEM_DOMAIN_VRAM,
			AMDGPU_GEM_CREATE_NO_CPU_ACCESS,
			&bo_mc, &va_handle);

	r = gpu_mem_free(bo, va_handle, bo_mc, 4096);
	CU_ASSERT_EQUAL(r, 0);

	/* Test GART Cacheable */
	bo = gpu_mem_alloc(device_handle,
			4096, 4096,
			AMDGPU_GEM_DOMAIN_GTT,
			0, &bo_mc, &va_handle);

	r = gpu_mem_free(bo, va_handle, bo_mc, 4096);
	CU_ASSERT_EQUAL(r, 0);

	/* Test GART USWC */
	bo = gpu_mem_alloc(device_handle,
			4096, 4096,
			AMDGPU_GEM_DOMAIN_GTT,
			AMDGPU_GEM_CREATE_CPU_GTT_USWC,
			&bo_mc, &va_handle);

	r = gpu_mem_free(bo, va_handle, bo_mc, 4096);
	CU_ASSERT_EQUAL(r, 0);
}

static void amdgpu_command_submission_gfx_separate_ibs(void)
{
	amdgpu_context_handle context_handle;
	amdgpu_bo_handle ib_result_handle, ib_result_ce_handle;
	void *ib_result_cpu, *ib_result_ce_cpu;
	uint64_t ib_result_mc_address, ib_result_ce_mc_address;
	struct amdgpu_cs_request ibs_request = {0};
	struct amdgpu_cs_ib_info ib_info[2];
	struct amdgpu_cs_fence fence_status = {0};
	uint32_t *ptr;
	uint32_t expired;
	amdgpu_bo_list_handle bo_list;
	amdgpu_va_handle va_handle, va_handle_ce;
	int r;

	r = amdgpu_cs_ctx_create(device_handle, &context_handle);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_alloc_and_map(device_handle, 4096, 4096,
				    AMDGPU_GEM_DOMAIN_GTT, 0,
				    &ib_result_handle, &ib_result_cpu,
				    &ib_result_mc_address, &va_handle);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_alloc_and_map(device_handle, 4096, 4096,
				    AMDGPU_GEM_DOMAIN_GTT, 0,
				    &ib_result_ce_handle, &ib_result_ce_cpu,
				    &ib_result_ce_mc_address, &va_handle_ce);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_get_bo_list(device_handle, ib_result_handle,
			       ib_result_ce_handle, &bo_list);
	CU_ASSERT_EQUAL(r, 0);

	memset(ib_info, 0, 2 * sizeof(struct amdgpu_cs_ib_info));

	/* IT_SET_CE_DE_COUNTERS */
	ptr = ib_result_ce_cpu;
	ptr[0] = 0xc0008900;
	ptr[1] = 0;
	ptr[2] = 0xc0008400;
	ptr[3] = 1;
	ib_info[0].ib_mc_address = ib_result_ce_mc_address;
	ib_info[0].size = 4;
	ib_info[0].flags = AMDGPU_IB_FLAG_CE;

	/* IT_WAIT_ON_CE_COUNTER */
	ptr = ib_result_cpu;
	ptr[0] = 0xc0008600;
	ptr[1] = 0x00000001;
	ib_info[1].ib_mc_address = ib_result_mc_address;
	ib_info[1].size = 2;

	ibs_request.ip_type = AMDGPU_HW_IP_GFX;
	ibs_request.number_of_ibs = 2;
	ibs_request.ibs = ib_info;
	ibs_request.resources = bo_list;
	ibs_request.fence_info.handle = NULL;

	r = amdgpu_cs_submit(context_handle, 0,&ibs_request, 1);

	CU_ASSERT_EQUAL(r, 0);

	fence_status.context = context_handle;
	fence_status.ip_type = AMDGPU_HW_IP_GFX;
	fence_status.fence = ibs_request.seq_no;

	r = amdgpu_cs_query_fence_status(&fence_status,
					 AMDGPU_TIMEOUT_INFINITE,
					 0, &expired);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_unmap_and_free(ib_result_handle, va_handle,
				     ib_result_mc_address, 4096);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_unmap_and_free(ib_result_ce_handle, va_handle_ce,
				     ib_result_ce_mc_address, 4096);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_list_destroy(bo_list);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_cs_ctx_free(context_handle);
	CU_ASSERT_EQUAL(r, 0);

}

static void amdgpu_command_submission_gfx_shared_ib(void)
{
	amdgpu_context_handle context_handle;
	amdgpu_bo_handle ib_result_handle;
	void *ib_result_cpu;
	uint64_t ib_result_mc_address;
	struct amdgpu_cs_request ibs_request = {0};
	struct amdgpu_cs_ib_info ib_info[2];
	struct amdgpu_cs_fence fence_status = {0};
	uint32_t *ptr;
	uint32_t expired;
	amdgpu_bo_list_handle bo_list;
	amdgpu_va_handle va_handle;
	int r;

	r = amdgpu_cs_ctx_create(device_handle, &context_handle);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_alloc_and_map(device_handle, 4096, 4096,
				    AMDGPU_GEM_DOMAIN_GTT, 0,
				    &ib_result_handle, &ib_result_cpu,
				    &ib_result_mc_address, &va_handle);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_get_bo_list(device_handle, ib_result_handle, NULL,
			       &bo_list);
	CU_ASSERT_EQUAL(r, 0);

	memset(ib_info, 0, 2 * sizeof(struct amdgpu_cs_ib_info));

	/* IT_SET_CE_DE_COUNTERS */
	ptr = ib_result_cpu;
	ptr[0] = 0xc0008900;
	ptr[1] = 0;
	ptr[2] = 0xc0008400;
	ptr[3] = 1;
	ib_info[0].ib_mc_address = ib_result_mc_address;
	ib_info[0].size = 4;
	ib_info[0].flags = AMDGPU_IB_FLAG_CE;

	ptr = (uint32_t *)ib_result_cpu + 4;
	ptr[0] = 0xc0008600;
	ptr[1] = 0x00000001;
	ib_info[1].ib_mc_address = ib_result_mc_address + 16;
	ib_info[1].size = 2;

	ibs_request.ip_type = AMDGPU_HW_IP_GFX;
	ibs_request.number_of_ibs = 2;
	ibs_request.ibs = ib_info;
	ibs_request.resources = bo_list;
	ibs_request.fence_info.handle = NULL;

	r = amdgpu_cs_submit(context_handle, 0, &ibs_request, 1);

	CU_ASSERT_EQUAL(r, 0);

	fence_status.context = context_handle;
	fence_status.ip_type = AMDGPU_HW_IP_GFX;
	fence_status.fence = ibs_request.seq_no;

	r = amdgpu_cs_query_fence_status(&fence_status,
					 AMDGPU_TIMEOUT_INFINITE,
					 0, &expired);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_unmap_and_free(ib_result_handle, va_handle,
				     ib_result_mc_address, 4096);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_list_destroy(bo_list);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_cs_ctx_free(context_handle);
	CU_ASSERT_EQUAL(r, 0);
}

static void amdgpu_command_submission_gfx(void)
{
	/* separate IB buffers for multi-IB submission */
	amdgpu_command_submission_gfx_separate_ibs();
	/* shared IB buffer for multi-IB submission */
	amdgpu_command_submission_gfx_shared_ib();
}

static void amdgpu_semaphore_test(void)
{
	amdgpu_context_handle context_handle[2];
	amdgpu_semaphore_handle sem;
	amdgpu_bo_handle ib_result_handle[2];
	void *ib_result_cpu[2];
	uint64_t ib_result_mc_address[2];
	struct amdgpu_cs_request ibs_request[2] = {0};
	struct amdgpu_cs_ib_info ib_info[2] = {0};
	struct amdgpu_cs_fence fence_status = {0};
	uint32_t *ptr;
	uint32_t expired;
	amdgpu_bo_list_handle bo_list[2];
	amdgpu_va_handle va_handle[2];
	int r, i;

	r = amdgpu_cs_create_semaphore(&sem);
	CU_ASSERT_EQUAL(r, 0);
	for (i = 0; i < 2; i++) {
		r = amdgpu_cs_ctx_create(device_handle, &context_handle[i]);
		CU_ASSERT_EQUAL(r, 0);

		r = amdgpu_bo_alloc_and_map(device_handle, 4096, 4096,
					    AMDGPU_GEM_DOMAIN_GTT, 0,
					    &ib_result_handle[i], &ib_result_cpu[i],
					    &ib_result_mc_address[i], &va_handle[i]);
		CU_ASSERT_EQUAL(r, 0);

		r = amdgpu_get_bo_list(device_handle, ib_result_handle[i],
				       NULL, &bo_list[i]);
		CU_ASSERT_EQUAL(r, 0);
	}

	/* 1. same context different engine */
	ptr = ib_result_cpu[0];
	ptr[0] = SDMA_NOP;
	ib_info[0].ib_mc_address = ib_result_mc_address[0];
	ib_info[0].size = 1;

	ibs_request[0].ip_type = AMDGPU_HW_IP_DMA;
	ibs_request[0].number_of_ibs = 1;
	ibs_request[0].ibs = &ib_info[0];
	ibs_request[0].resources = bo_list[0];
	ibs_request[0].fence_info.handle = NULL;
	r = amdgpu_cs_submit(context_handle[0], 0,&ibs_request[0], 1);
	CU_ASSERT_EQUAL(r, 0);
	r = amdgpu_cs_signal_semaphore(context_handle[0], AMDGPU_HW_IP_DMA, 0, 0, sem);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_cs_wait_semaphore(context_handle[0], AMDGPU_HW_IP_GFX, 0, 0, sem);
	CU_ASSERT_EQUAL(r, 0);
	ptr = ib_result_cpu[1];
	ptr[0] = GFX_COMPUTE_NOP;
	ib_info[1].ib_mc_address = ib_result_mc_address[1];
	ib_info[1].size = 1;

	ibs_request[1].ip_type = AMDGPU_HW_IP_GFX;
	ibs_request[1].number_of_ibs = 1;
	ibs_request[1].ibs = &ib_info[1];
	ibs_request[1].resources = bo_list[1];
	ibs_request[1].fence_info.handle = NULL;

	r = amdgpu_cs_submit(context_handle[0], 0,&ibs_request[1], 1);
	CU_ASSERT_EQUAL(r, 0);

	fence_status.context = context_handle[0];
	fence_status.ip_type = AMDGPU_HW_IP_GFX;
	fence_status.fence = ibs_request[1].seq_no;
	r = amdgpu_cs_query_fence_status(&fence_status,
					 500000000, 0, &expired);
	CU_ASSERT_EQUAL(r, 0);
	CU_ASSERT_EQUAL(expired, true);

	/* 2. same engine different context */
	ptr = ib_result_cpu[0];
	ptr[0] = GFX_COMPUTE_NOP;
	ib_info[0].ib_mc_address = ib_result_mc_address[0];
	ib_info[0].size = 1;

	ibs_request[0].ip_type = AMDGPU_HW_IP_GFX;
	ibs_request[0].number_of_ibs = 1;
	ibs_request[0].ibs = &ib_info[0];
	ibs_request[0].resources = bo_list[0];
	ibs_request[0].fence_info.handle = NULL;
	r = amdgpu_cs_submit(context_handle[0], 0,&ibs_request[0], 1);
	CU_ASSERT_EQUAL(r, 0);
	r = amdgpu_cs_signal_semaphore(context_handle[0], AMDGPU_HW_IP_GFX, 0, 0, sem);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_cs_wait_semaphore(context_handle[1], AMDGPU_HW_IP_GFX, 0, 0, sem);
	CU_ASSERT_EQUAL(r, 0);
	ptr = ib_result_cpu[1];
	ptr[0] = GFX_COMPUTE_NOP;
	ib_info[1].ib_mc_address = ib_result_mc_address[1];
	ib_info[1].size = 1;

	ibs_request[1].ip_type = AMDGPU_HW_IP_GFX;
	ibs_request[1].number_of_ibs = 1;
	ibs_request[1].ibs = &ib_info[1];
	ibs_request[1].resources = bo_list[1];
	ibs_request[1].fence_info.handle = NULL;
	r = amdgpu_cs_submit(context_handle[1], 0,&ibs_request[1], 1);

	CU_ASSERT_EQUAL(r, 0);

	fence_status.context = context_handle[1];
	fence_status.ip_type = AMDGPU_HW_IP_GFX;
	fence_status.fence = ibs_request[1].seq_no;
	r = amdgpu_cs_query_fence_status(&fence_status,
					 500000000, 0, &expired);
	CU_ASSERT_EQUAL(r, 0);
	CU_ASSERT_EQUAL(expired, true);
	for (i = 0; i < 2; i++) {
		r = amdgpu_bo_unmap_and_free(ib_result_handle[i], va_handle[i],
					     ib_result_mc_address[i], 4096);
		CU_ASSERT_EQUAL(r, 0);

		r = amdgpu_bo_list_destroy(bo_list[i]);
		CU_ASSERT_EQUAL(r, 0);

		r = amdgpu_cs_ctx_free(context_handle[i]);
		CU_ASSERT_EQUAL(r, 0);
	}

	r = amdgpu_cs_destroy_semaphore(sem);
	CU_ASSERT_EQUAL(r, 0);
}

static void amdgpu_command_submission_compute(void)
{
	amdgpu_context_handle context_handle;
	amdgpu_bo_handle ib_result_handle;
	void *ib_result_cpu;
	uint64_t ib_result_mc_address;
	struct amdgpu_cs_request ibs_request;
	struct amdgpu_cs_ib_info ib_info;
	struct amdgpu_cs_fence fence_status;
	uint32_t *ptr;
	uint32_t expired;
	int i, r, instance;
	amdgpu_bo_list_handle bo_list;
	amdgpu_va_handle va_handle;

	r = amdgpu_cs_ctx_create(device_handle, &context_handle);
	CU_ASSERT_EQUAL(r, 0);

	amdgpu_vprintf("\n");
	for (instance = 0; instance < 8; instance++) {
		amdgpu_vprintf("    Submit NOP command on ring %d.\n", instance);
		r = amdgpu_bo_alloc_and_map(device_handle, 4096, 4096,
					    AMDGPU_GEM_DOMAIN_GTT, 0,
					    &ib_result_handle, &ib_result_cpu,
					    &ib_result_mc_address, &va_handle);
		CU_ASSERT_EQUAL(r, 0);

		r = amdgpu_get_bo_list(device_handle, ib_result_handle, NULL,
				       &bo_list);
		CU_ASSERT_EQUAL(r, 0);

		ptr = ib_result_cpu;
		for (i = 0; i < 16; ++i)
			ptr[i] = 0xffff1000;

		memset(&ib_info, 0, sizeof(struct amdgpu_cs_ib_info));
		ib_info.ib_mc_address = ib_result_mc_address;
		ib_info.size = 16;

		memset(&ibs_request, 0, sizeof(struct amdgpu_cs_request));
		ibs_request.ip_type = AMDGPU_HW_IP_COMPUTE;
		ibs_request.ring = instance;
		ibs_request.number_of_ibs = 1;
		ibs_request.ibs = &ib_info;
		ibs_request.resources = bo_list;
		ibs_request.fence_info.handle = NULL;

		memset(&fence_status, 0, sizeof(struct amdgpu_cs_fence));
		r = amdgpu_cs_submit(context_handle, 0,&ibs_request, 1);
		CU_ASSERT_EQUAL(r, 0);

		fence_status.context = context_handle;
		fence_status.ip_type = AMDGPU_HW_IP_COMPUTE;
		fence_status.ring = instance;
		fence_status.fence = ibs_request.seq_no;

		r = amdgpu_cs_query_fence_status(&fence_status,
						 AMDGPU_TIMEOUT_INFINITE,
						 0, &expired);
		CU_ASSERT_EQUAL(r, 0);

		r = amdgpu_bo_list_destroy(bo_list);
		CU_ASSERT_EQUAL(r, 0);

		r = amdgpu_bo_unmap_and_free(ib_result_handle, va_handle,
					     ib_result_mc_address, 4096);
		CU_ASSERT_EQUAL(r, 0);
	}

	r = amdgpu_cs_ctx_free(context_handle);
	CU_ASSERT_EQUAL(r, 0);
}

/*
 * caller need create/release:
 * pm4_src, resources, ib_info, and ibs_request
 * submit command stream described in ibs_request and wait for this IB accomplished
 */
static void amdgpu_sdma_test_exec_cs(amdgpu_context_handle context_handle,
				 int instance, int pm4_dw, uint32_t *pm4_src,
				 int res_cnt, amdgpu_bo_handle *resources,
				 struct amdgpu_cs_ib_info *ib_info,
				 struct amdgpu_cs_request *ibs_request)
{
	int r;
	uint32_t expired;
	uint32_t *ring_ptr;
	amdgpu_bo_handle ib_result_handle;
	void *ib_result_cpu;
	uint64_t ib_result_mc_address;
	struct amdgpu_cs_fence fence_status = {0};
	amdgpu_bo_handle *all_res = alloca(sizeof(resources[0]) * (res_cnt + 1));
	amdgpu_va_handle va_handle;

	/* prepare CS */
	CU_ASSERT_NOT_EQUAL(pm4_src, NULL);
	CU_ASSERT_NOT_EQUAL(resources, NULL);
	CU_ASSERT_NOT_EQUAL(ib_info, NULL);
	CU_ASSERT_NOT_EQUAL(ibs_request, NULL);
	CU_ASSERT_TRUE(pm4_dw <= 1024);

	/* allocate IB */
	r = amdgpu_bo_alloc_and_map(device_handle, 4096, 4096,
				    AMDGPU_GEM_DOMAIN_GTT, 0,
				    &ib_result_handle, &ib_result_cpu,
				    &ib_result_mc_address, &va_handle);
	CU_ASSERT_EQUAL(r, 0);

	/* copy PM4 packet to ring from caller */
	ring_ptr = ib_result_cpu;
	memcpy(ring_ptr, pm4_src, pm4_dw * sizeof(*pm4_src));

	ib_info->ib_mc_address = ib_result_mc_address;
	ib_info->size = pm4_dw;

	ibs_request->ip_type = AMDGPU_HW_IP_DMA;
	ibs_request->ring = instance;
	ibs_request->number_of_ibs = 1;
	ibs_request->ibs = ib_info;
	ibs_request->fence_info.handle = NULL;

	memcpy(all_res, resources, sizeof(resources[0]) * res_cnt);
	all_res[res_cnt] = ib_result_handle;

	r = amdgpu_bo_list_create(device_handle, res_cnt+1, all_res,
				  NULL, &ibs_request->resources);
	CU_ASSERT_EQUAL(r, 0);

	CU_ASSERT_NOT_EQUAL(ibs_request, NULL);

	/* submit CS */
	r = amdgpu_cs_submit(context_handle, 0, ibs_request, 1);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_list_destroy(ibs_request->resources);
	CU_ASSERT_EQUAL(r, 0);

	fence_status.ip_type = AMDGPU_HW_IP_DMA;
	fence_status.ring = ibs_request->ring;
	fence_status.context = context_handle;
	fence_status.fence = ibs_request->seq_no;

	/* wait for IB accomplished */
	r = amdgpu_cs_query_fence_status(&fence_status,
					 AMDGPU_TIMEOUT_INFINITE,
					 0, &expired);
	CU_ASSERT_EQUAL(r, 0);
	CU_ASSERT_EQUAL(expired, true);

	r = amdgpu_bo_unmap_and_free(ib_result_handle, va_handle,
				     ib_result_mc_address, 4096);
	CU_ASSERT_EQUAL(r, 0);
}

static void amdgpu_command_submission_sdma_write_linear(void)
{
	const int sdma_write_length = 128;
	const int pm4_dw = 256;
	amdgpu_context_handle context_handle;
	amdgpu_bo_handle bo;
	amdgpu_bo_handle *resources;
	uint32_t *pm4;
	struct amdgpu_cs_ib_info *ib_info;
	struct amdgpu_cs_request *ibs_request;
	uint64_t bo_mc;
	volatile uint32_t *bo_cpu;
	int i, j, r, loop;
	uint64_t gtt_flags[2] = {0, AMDGPU_GEM_CREATE_CPU_GTT_USWC};
	amdgpu_va_handle va_handle;

	pm4 = calloc(pm4_dw, sizeof(*pm4));
	CU_ASSERT_NOT_EQUAL(pm4, NULL);

	ib_info = calloc(1, sizeof(*ib_info));
	CU_ASSERT_NOT_EQUAL(ib_info, NULL);

	ibs_request = calloc(1, sizeof(*ibs_request));
	CU_ASSERT_NOT_EQUAL(ibs_request, NULL);

	r = amdgpu_cs_ctx_create(device_handle, &context_handle);
	CU_ASSERT_EQUAL(r, 0);

	/* prepare resource */
	resources = calloc(1, sizeof(amdgpu_bo_handle));
	CU_ASSERT_NOT_EQUAL(resources, NULL);

	loop = 0;
	while(loop < 2) {
		/* allocate UC bo for sDMA use */
		r = amdgpu_bo_alloc_and_map(device_handle,
					    sdma_write_length * sizeof(uint32_t),
					    4096, AMDGPU_GEM_DOMAIN_GTT,
					    gtt_flags[loop], &bo, (void**)&bo_cpu,
					    &bo_mc, &va_handle);
		CU_ASSERT_EQUAL(r, 0);

		/* clear bo */
		memset((void*)bo_cpu, 0, sdma_write_length * sizeof(uint32_t));


		resources[0] = bo;

		/* fullfill PM4: test DMA write-linear */
		i = j = 0;
		pm4[i++] = SDMA_PACKET(SDMA_OPCODE_WRITE,
				SDMA_WRITE_SUB_OPCODE_LINEAR, 0);
		pm4[i++] = 0xffffffff & bo_mc;
		pm4[i++] = (0xffffffff00000000 & bo_mc) >> 32;
		pm4[i++] = sdma_write_length;
		while(j++ < sdma_write_length)
			pm4[i++] = 0xdeadbeaf;

		amdgpu_sdma_test_exec_cs(context_handle, 0,
					i, pm4,
					1, resources,
					ib_info, ibs_request);

		/* verify if SDMA test result meets with expected */
		i = 0;
		while(i < sdma_write_length) {
			CU_ASSERT_EQUAL(bo_cpu[i++], 0xdeadbeaf);
		}

		r = amdgpu_bo_unmap_and_free(bo, va_handle, bo_mc,
					     sdma_write_length * sizeof(uint32_t));
		CU_ASSERT_EQUAL(r, 0);
		loop++;
	}
	/* clean resources */
	free(resources);
	free(ibs_request);
	free(ib_info);
	free(pm4);

	/* end of test */
	r = amdgpu_cs_ctx_free(context_handle);
	CU_ASSERT_EQUAL(r, 0);
}

static void amdgpu_command_submission_sdma_const_fill(void)
{
	const int sdma_write_length = 1024 * 1024;
	const int pm4_dw = 256;
	amdgpu_context_handle context_handle;
	amdgpu_bo_handle bo;
	amdgpu_bo_handle *resources;
	uint32_t *pm4;
	struct amdgpu_cs_ib_info *ib_info;
	struct amdgpu_cs_request *ibs_request;
	uint64_t bo_mc;
	volatile uint32_t *bo_cpu;
	int i, j, r, loop;
	uint64_t gtt_flags[2] = {0, AMDGPU_GEM_CREATE_CPU_GTT_USWC};
	amdgpu_va_handle va_handle;

	pm4 = calloc(pm4_dw, sizeof(*pm4));
	CU_ASSERT_NOT_EQUAL(pm4, NULL);

	ib_info = calloc(1, sizeof(*ib_info));
	CU_ASSERT_NOT_EQUAL(ib_info, NULL);

	ibs_request = calloc(1, sizeof(*ibs_request));
	CU_ASSERT_NOT_EQUAL(ibs_request, NULL);

	r = amdgpu_cs_ctx_create(device_handle, &context_handle);
	CU_ASSERT_EQUAL(r, 0);

	/* prepare resource */
	resources = calloc(1, sizeof(amdgpu_bo_handle));
	CU_ASSERT_NOT_EQUAL(resources, NULL);

	loop = 0;
	while(loop < 2) {
		/* allocate UC bo for sDMA use */
		r = amdgpu_bo_alloc_and_map(device_handle,
					    sdma_write_length, 4096,
					    AMDGPU_GEM_DOMAIN_GTT,
					    gtt_flags[loop], &bo, (void**)&bo_cpu,
					    &bo_mc, &va_handle);
		CU_ASSERT_EQUAL(r, 0);

		/* clear bo */
		memset((void*)bo_cpu, 0, sdma_write_length);

		resources[0] = bo;

		/* fullfill PM4: test DMA const fill */
		i = j = 0;
		pm4[i++] = SDMA_PACKET(SDMA_OPCODE_CONSTANT_FILL, 0,
				   SDMA_CONSTANT_FILL_EXTRA_SIZE(2));
		pm4[i++] = 0xffffffff & bo_mc;
		pm4[i++] = (0xffffffff00000000 & bo_mc) >> 32;
		pm4[i++] = 0xdeadbeaf;
		pm4[i++] = sdma_write_length;

		amdgpu_sdma_test_exec_cs(context_handle, 0,
					i, pm4,
					1, resources,
					ib_info, ibs_request);

		/* verify if SDMA test result meets with expected */
		i = 0;
		while(i < (sdma_write_length / 4)) {
			CU_ASSERT_EQUAL(bo_cpu[i++], 0xdeadbeaf);
		}

		r = amdgpu_bo_unmap_and_free(bo, va_handle, bo_mc,
					     sdma_write_length);
		CU_ASSERT_EQUAL(r, 0);
		loop++;
	}
	/* clean resources */
	free(resources);
	free(ibs_request);
	free(ib_info);
	free(pm4);

	/* end of test */
	r = amdgpu_cs_ctx_free(context_handle);
	CU_ASSERT_EQUAL(r, 0);
}

static void amdgpu_command_submission_sdma_copy_linear(void)
{
	const int sdma_write_length = 1024;
	const int pm4_dw = 256;
	amdgpu_context_handle context_handle;
	amdgpu_bo_handle bo1, bo2;
	amdgpu_bo_handle *resources;
	uint32_t *pm4;
	struct amdgpu_cs_ib_info *ib_info;
	struct amdgpu_cs_request *ibs_request;
	uint64_t bo1_mc, bo2_mc;
	volatile unsigned char *bo1_cpu, *bo2_cpu;
	int i, j, r, loop1, loop2;
	uint64_t gtt_flags[2] = {0, AMDGPU_GEM_CREATE_CPU_GTT_USWC};
	amdgpu_va_handle bo1_va_handle, bo2_va_handle;

	pm4 = calloc(pm4_dw, sizeof(*pm4));
	CU_ASSERT_NOT_EQUAL(pm4, NULL);

	ib_info = calloc(1, sizeof(*ib_info));
	CU_ASSERT_NOT_EQUAL(ib_info, NULL);

	ibs_request = calloc(1, sizeof(*ibs_request));
	CU_ASSERT_NOT_EQUAL(ibs_request, NULL);

	r = amdgpu_cs_ctx_create(device_handle, &context_handle);
	CU_ASSERT_EQUAL(r, 0);

	/* prepare resource */
	resources = calloc(2, sizeof(amdgpu_bo_handle));
	CU_ASSERT_NOT_EQUAL(resources, NULL);

	loop1 = loop2 = 0;
	/* run 9 circle to test all mapping combination */
	while(loop1 < 2) {
		while(loop2 < 2) {
			/* allocate UC bo1for sDMA use */
			r = amdgpu_bo_alloc_and_map(device_handle,
						    sdma_write_length, 4096,
						    AMDGPU_GEM_DOMAIN_GTT,
						    gtt_flags[loop1], &bo1,
						    (void**)&bo1_cpu, &bo1_mc,
						    &bo1_va_handle);
			CU_ASSERT_EQUAL(r, 0);

			/* set bo1 */
			memset((void*)bo1_cpu, 0xaa, sdma_write_length);

			/* allocate UC bo2 for sDMA use */
			r = amdgpu_bo_alloc_and_map(device_handle,
						    sdma_write_length, 4096,
						    AMDGPU_GEM_DOMAIN_GTT,
						    gtt_flags[loop2], &bo2,
						    (void**)&bo2_cpu, &bo2_mc,
						    &bo2_va_handle);
			CU_ASSERT_EQUAL(r, 0);

			/* clear bo2 */
			memset((void*)bo2_cpu, 0, sdma_write_length);

			resources[0] = bo1;
			resources[1] = bo2;

			/* fullfill PM4: test DMA copy linear */
			i = j = 0;
			pm4[i++] = SDMA_PACKET(SDMA_OPCODE_COPY, SDMA_COPY_SUB_OPCODE_LINEAR, 0);
			pm4[i++] = sdma_write_length;
			pm4[i++] = 0;
			pm4[i++] = 0xffffffff & bo1_mc;
			pm4[i++] = (0xffffffff00000000 & bo1_mc) >> 32;
			pm4[i++] = 0xffffffff & bo2_mc;
			pm4[i++] = (0xffffffff00000000 & bo2_mc) >> 32;


			amdgpu_sdma_test_exec_cs(context_handle, 0,
						i, pm4,
						2, resources,
						ib_info, ibs_request);

			/* verify if SDMA test result meets with expected */
			i = 0;
			while(i < sdma_write_length) {
				CU_ASSERT_EQUAL(bo2_cpu[i++], 0xaa);
			}
			r = amdgpu_bo_unmap_and_free(bo1, bo1_va_handle, bo1_mc,
						     sdma_write_length);
			CU_ASSERT_EQUAL(r, 0);
			r = amdgpu_bo_unmap_and_free(bo2, bo2_va_handle, bo2_mc,
						     sdma_write_length);
			CU_ASSERT_EQUAL(r, 0);
			loop2++;
		}
		loop1++;
	}
	/* clean resources */
	free(resources);
	free(ibs_request);
	free(ib_info);
	free(pm4);

	/* end of test */
	r = amdgpu_cs_ctx_free(context_handle);
	CU_ASSERT_EQUAL(r, 0);
}

static void amdgpu_command_submission_sdma(void)
{
	amdgpu_command_submission_sdma_write_linear();
	amdgpu_command_submission_sdma_const_fill();
	amdgpu_command_submission_sdma_copy_linear();
}

static void amdgpu_command_submission_multi_fence_wait_all(bool wait_all)
{
	amdgpu_context_handle context_handle;
	amdgpu_bo_handle ib_result_handle, ib_result_ce_handle;
	void *ib_result_cpu, *ib_result_ce_cpu;
	uint64_t ib_result_mc_address, ib_result_ce_mc_address;
	struct amdgpu_cs_request ibs_request[2] = {0};
	struct amdgpu_cs_ib_info ib_info[2];
	struct amdgpu_cs_fence fence_status[2] = {0};
	uint32_t *ptr;
	uint32_t expired;
	amdgpu_bo_list_handle bo_list;
	amdgpu_va_handle va_handle, va_handle_ce;
	int r;
	int i, ib_cs_num = 2;

	r = amdgpu_cs_ctx_create(device_handle, &context_handle);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_alloc_and_map(device_handle, 4096, 4096,
				    AMDGPU_GEM_DOMAIN_GTT, 0,
				    &ib_result_handle, &ib_result_cpu,
				    &ib_result_mc_address, &va_handle);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_alloc_and_map(device_handle, 4096, 4096,
				    AMDGPU_GEM_DOMAIN_GTT, 0,
				    &ib_result_ce_handle, &ib_result_ce_cpu,
				    &ib_result_ce_mc_address, &va_handle_ce);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_get_bo_list(device_handle, ib_result_handle,
			       ib_result_ce_handle, &bo_list);
	CU_ASSERT_EQUAL(r, 0);

	memset(ib_info, 0, 2 * sizeof(struct amdgpu_cs_ib_info));

	/* IT_SET_CE_DE_COUNTERS */
	ptr = ib_result_ce_cpu;
	ptr[0] = 0xc0008900;
	ptr[1] = 0;
	ptr[2] = 0xc0008400;
	ptr[3] = 1;
	ib_info[0].ib_mc_address = ib_result_ce_mc_address;
	ib_info[0].size = 4;
	ib_info[0].flags = AMDGPU_IB_FLAG_CE;

	/* IT_WAIT_ON_CE_COUNTER */
	ptr = ib_result_cpu;
	ptr[0] = 0xc0008600;
	ptr[1] = 0x00000001;
	ib_info[1].ib_mc_address = ib_result_mc_address;
	ib_info[1].size = 2;

	for (i = 0; i < ib_cs_num; i++) {
		ibs_request[i].ip_type = AMDGPU_HW_IP_GFX;
		ibs_request[i].number_of_ibs = 2;
		ibs_request[i].ibs = ib_info;
		ibs_request[i].resources = bo_list;
		ibs_request[i].fence_info.handle = NULL;
	}

	r = amdgpu_cs_submit(context_handle, 0,ibs_request, ib_cs_num);

	CU_ASSERT_EQUAL(r, 0);

	for (i = 0; i < ib_cs_num; i++) {
		fence_status[i].context = context_handle;
		fence_status[i].ip_type = AMDGPU_HW_IP_GFX;
		fence_status[i].fence = ibs_request[i].seq_no;
	}

	r = amdgpu_cs_wait_fences(fence_status, ib_cs_num, wait_all,
				AMDGPU_TIMEOUT_INFINITE,
				&expired, NULL);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_unmap_and_free(ib_result_handle, va_handle,
				     ib_result_mc_address, 4096);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_unmap_and_free(ib_result_ce_handle, va_handle_ce,
				     ib_result_ce_mc_address, 4096);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_list_destroy(bo_list);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_cs_ctx_free(context_handle);
	CU_ASSERT_EQUAL(r, 0);
}

static void amdgpu_command_submission_multi_fence(void)
{
	amdgpu_command_submission_multi_fence_wait_all(true);
	amdgpu_command_submission_multi_fence_wait_all(false);
}

static void amdgpu_userptr_test(void)
{
	int i, r, j;
	uint32_t *pm4 = NULL;
	uint64_t bo_mc;
	void *ptr = NULL;
	int pm4_dw = 256;
	int sdma_write_length = 4;
	amdgpu_bo_handle handle;
	amdgpu_context_handle context_handle;
	struct amdgpu_cs_ib_info *ib_info;
	struct amdgpu_cs_request *ibs_request;
	amdgpu_bo_handle buf_handle;
	amdgpu_va_handle va_handle;

	pm4 = calloc(pm4_dw, sizeof(*pm4));
	CU_ASSERT_NOT_EQUAL(pm4, NULL);

	ib_info = calloc(1, sizeof(*ib_info));
	CU_ASSERT_NOT_EQUAL(ib_info, NULL);

	ibs_request = calloc(1, sizeof(*ibs_request));
	CU_ASSERT_NOT_EQUAL(ibs_request, NULL);

	r = amdgpu_cs_ctx_create(device_handle, &context_handle);
	CU_ASSERT_EQUAL(r, 0);

	posix_memalign(&ptr, sysconf(_SC_PAGE_SIZE), BUFFER_SIZE);
	CU_ASSERT_NOT_EQUAL(ptr, NULL);
	memset(ptr, 0, BUFFER_SIZE);

	r = amdgpu_create_bo_from_user_mem(device_handle,
					   ptr, BUFFER_SIZE, &buf_handle);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_va_range_alloc(device_handle,
				  amdgpu_gpu_va_range_general,
				  BUFFER_SIZE, 1, 0, &bo_mc,
				  &va_handle, 0);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_bo_va_op(buf_handle, 0, BUFFER_SIZE, bo_mc, 0, AMDGPU_VA_OP_MAP);
	CU_ASSERT_EQUAL(r, 0);

	handle = buf_handle;

	j = i = 0;
	pm4[i++] = SDMA_PACKET(SDMA_OPCODE_WRITE,
			       SDMA_WRITE_SUB_OPCODE_LINEAR, 0);
	pm4[i++] = 0xffffffff & bo_mc;
	pm4[i++] = (0xffffffff00000000 & bo_mc) >> 32;
	pm4[i++] = sdma_write_length;

	while (j++ < sdma_write_length)
		pm4[i++] = 0xdeadbeaf;

	amdgpu_sdma_test_exec_cs(context_handle, 0,
				 i, pm4,
				 1, &handle,
				 ib_info, ibs_request);
	i = 0;
	while (i < sdma_write_length) {
		CU_ASSERT_EQUAL(((int*)ptr)[i++], 0xdeadbeaf);
	}
	free(ibs_request);
	free(ib_info);
	free(pm4);

	r = amdgpu_bo_va_op(buf_handle, 0, BUFFER_SIZE, bo_mc, 0, AMDGPU_VA_OP_UNMAP);
	CU_ASSERT_EQUAL(r, 0);
	r = amdgpu_va_range_free(va_handle);
	CU_ASSERT_EQUAL(r, 0);
	r = amdgpu_bo_free(buf_handle);
	CU_ASSERT_EQUAL(r, 0);
	free(ptr);

	r = amdgpu_cs_ctx_free(context_handle);
	CU_ASSERT_EQUAL(r, 0);
}

static void amdgpu_svm_test(void)
{
	int r;
	uint64_t svm_mc;
	amdgpu_va_handle va_handle[SVM_TEST_COUNT];
	void *cpu;
	uint64_t start;
	uint64_t end;
	int i;

	r = amdgpu_svm_init(device_handle);
	CU_ASSERT_EQUAL(r, 0);

	r = amdgpu_va_range_query(device_handle,
		amdgpu_gpu_va_range_svm, &start, &end);
	CU_ASSERT_EQUAL(r, 0);
	amdgpu_vprintf("\n");
	amdgpu_vprintf("SVM range is from 0x%llx to 0x%llx.\n", start, end);

	/* If there is no SVM range, exit this function.*/
	if (start == 0ULL && end == 0ULL)
		return;

	CU_ASSERT(start < end);
	CU_ASSERT(end - start >= 1ULL * 1024ULL * 1024ULL * 1024ULL);

	for (i = 0; i < SVM_TEST_COUNT; i++) {
		r = amdgpu_va_range_alloc(device_handle,
					  amdgpu_gpu_va_range_svm,
					  64 * 1024 * 1024, 1, 0, &svm_mc,
					  &va_handle[i], 0);
		CU_ASSERT_EQUAL(r, 0);
		amdgpu_vprintf("Allocate SVM MC 0x%llx.\n", svm_mc);

		r = amdgpu_svm_commit(va_handle[i], &cpu);
		CU_ASSERT_EQUAL(r, 0);
		CU_ASSERT_PTR_NOT_NULL(cpu);
		CU_ASSERT_EQUAL(svm_mc, (uint64_t)cpu);
	}

	for (i = 0; i < SVM_TEST_COUNT; i++) {
		r = amdgpu_svm_uncommit(va_handle[i]);
		CU_ASSERT_EQUAL(r, 0);

		r = amdgpu_va_range_free(va_handle[i]);
		CU_ASSERT_EQUAL(r, 0);
	}

	amdgpu_svm_deinit(device_handle);
}

static void amdgpu_multi_svm_test(void)
{
	int r;
	int i;
	uint64_t svm_mcs[MAX_CARDS_SUPPORTED];
	amdgpu_va_handle va_handles[MAX_CARDS_SUPPORTED];
	amdgpu_device_handle device_handles[MAX_CARDS_SUPPORTED];
	uint32_t major_version;
	uint32_t minor_version;
	int num_devices;

	device_handles[0] = device_handle;
	num_devices = amdgpu_num_devices();

	r = amdgpu_svm_init(device_handles[0]);
	CU_ASSERT_EQUAL(r, 0);

	for (i = 1; i < num_devices; i++)
		if (drm_amdgpu[i] > 0) {
			r = amdgpu_device_initialize(drm_amdgpu[i], &major_version,
					&minor_version, &device_handles[i]);
			CU_ASSERT_EQUAL(r, 0);

			r = amdgpu_svm_init(device_handles[i]);
			CU_ASSERT_EQUAL(r, 0);
		}

	amdgpu_vprintf("\n");
	amdgpu_vprintf("    Testing to alloc and free SVM in all GPUs.\n");
	amdgpu_vprintf("    The svm_mcs generally are same.\n");
	for (i = 0; i < num_devices; i++)
		if (drm_amdgpu[i] > 0) {
			r = amdgpu_va_range_alloc(device_handles[i],
						  amdgpu_gpu_va_range_svm,
						  0x1000000, 1, 0, &svm_mcs[i],
						  &va_handles[i], 0);
			CU_ASSERT_EQUAL(r, 0);
			amdgpu_vprintf("        card %d, svm_mc 0x%llx\n", i, svm_mcs[i]);
			amdgpu_warning(svm_mcs[i] != svm_mcs[0],
				"The SVM from different GPUs should be able to be allocated"
				" from same location.");
			r = amdgpu_va_range_free(va_handles[i]);
			CU_ASSERT_EQUAL(r, 0);
		}

	amdgpu_vprintf("    Testing to alloc SVM in all GPUs.\n");
	amdgpu_vprintf("    The svm_mcs are generally different by 0x1000000\n");
	for (i = 0; i < num_devices; i++)
		if (drm_amdgpu[i] > 0) {
			r = amdgpu_va_range_alloc(device_handles[i],
						  amdgpu_gpu_va_range_svm,
						  0x1000000, 1, 0, &svm_mcs[i],
						  &va_handles[i], 0);
			CU_ASSERT_EQUAL(r, 0);
			amdgpu_vprintf("        card %d, svm_mc 0x%llx\n", i, svm_mcs[i]);
			amdgpu_warning(svm_mcs[i] - svm_mcs[0] != 0x1000000 * i,
				"The SVM from GPUs should be allocated sequentially.");
		}

	for (i = 0; i < num_devices; i++)
		if (drm_amdgpu[i] > 0) {
			r = amdgpu_va_range_free(va_handles[i]);
			CU_ASSERT_EQUAL(r, 0);
		}

	for (i = 1; i < num_devices; i++)
		if (drm_amdgpu[i] > 0) {
			amdgpu_svm_deinit(device_handles[i]);
			r = amdgpu_device_deinitialize(device_handles[i]);
			CU_ASSERT_EQUAL(r, 0);
		}

	amdgpu_svm_deinit(device_handles[0]);
}

#define VA_RANGE_TEST_CNT 66
#define VA_RANGE_TEST_INT_BEL_CNT 20
#define VA_RANGE_TEST_INT_ABO_CNT 20
static void amdgpu_va_range_test(void)
{
	amdgpu_va_handle va_handles[VA_RANGE_TEST_CNT+VA_RANGE_TEST_INT_BEL_CNT+VA_RANGE_TEST_INT_ABO_CNT];
	uint64_t va;
	int i, r;

	amdgpu_vprintf("\n");
	amdgpu_vprintf("    Testing to alloc and free VA in user defined range.\n");
	memset(va_handles, 0, sizeof(va_handles));
	for (i = 0; i < VA_RANGE_TEST_CNT; i++) {
		r = amdgpu_va_range_alloc_in_range(device_handle,
						amdgpu_gpu_va_range_general,
						0x1000000, 9, 0,
						0x800000000, 0x840000000,
						&va, &va_handles[i], 0);
		amdgpu_vprintf("	test loop %d, alloc %s\n", i, (r==0)? "success" : "fail");
		if (!r)
			amdgpu_vprintf("	alloc on addr %#llx\n", va);
		CU_ASSERT_TRUE((r == 0) ||
			(r && i>=(0x840000000-0x800000000)/0x1000000));
	}
	for (i = VA_RANGE_TEST_CNT; i < VA_RANGE_TEST_CNT+VA_RANGE_TEST_INT_BEL_CNT; i++) {
		r = amdgpu_va_range_alloc_in_range(device_handle,
						amdgpu_gpu_va_range_general,
						0x1000000, 9, 0,
						0x600000000, 0x840000000,
						&va, &va_handles[i], 0);
		amdgpu_vprintf("	test loop %d, alloc %s\n", i, (r==0)? "success" : "fail");
		if (!r)
			amdgpu_vprintf("	alloc on addr %#llx\n", va);
		CU_ASSERT_TRUE (r == 0 && va <=0x800000000);
	}
	for (i = VA_RANGE_TEST_CNT+VA_RANGE_TEST_INT_BEL_CNT; i < VA_RANGE_TEST_CNT+VA_RANGE_TEST_INT_BEL_CNT+VA_RANGE_TEST_INT_ABO_CNT; i++) {
		r = amdgpu_va_range_alloc_in_range(device_handle,
						amdgpu_gpu_va_range_general,
						0x1000000, 9, 0,
						0x800000000, 0x940000000,
						&va, &va_handles[i], 0);
		amdgpu_vprintf("	test loop %d, alloc %s\n", i, (r==0)? "success" : "fail");
		if (!r)
			amdgpu_vprintf("	alloc on addr %#llx\n", va);
		CU_ASSERT_TRUE (r == 0 && va >= 0x840000000);
	}
	for (i = 0; i < VA_RANGE_TEST_CNT+VA_RANGE_TEST_INT_BEL_CNT+VA_RANGE_TEST_INT_ABO_CNT; i++) {
		r = amdgpu_va_range_free(va_handles[i]);
		CU_ASSERT_EQUAL(r, 0);
	}
}
